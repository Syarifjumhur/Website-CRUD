<?php

//menu utama
define ("language", 'Bahasa');
define ("home", 'Beranda');
define ("services", 'layanan');
define ("gallery", 'Galleri');
define ("aboutus", 'Tentang Kami');
define ("contactus", 'Kontak');

//tombol
define ("moredetail", "Layanan Kami");
define ("buttoncontinue", "lihat Galeri Kami");
define ("buttonsendemail", "Kirim Pesan");

//judul
define ("labelgallery", "Galeri");
define ("labelgallerydescription", "Layanan Kami");
define ("labelservices", "Layanan");
define ("labelaboutus", "Sekilas Tentang Kami");
define ("labelcontactus", "Kontak Kami");

//form email
define ("placename", "Nama Anda...");
define ("placesubject", "Subjek...");
define ("placeemail", "Alamat Email Anda...");
define ("placemessage", "Isi Pesan...");
define ("buttonsendmail", "Kirim Pesan");

//footer
define ("labellocation", "Lokasi");
define ("labelinfo", "Informasi Lengkap");
define ("labelheadoffice", "Kantor Pusat");
define ("labelphone", "Telepon");
define ("labelemail", "Email");
define ("labelsosmed", "Media Sosial");

?>
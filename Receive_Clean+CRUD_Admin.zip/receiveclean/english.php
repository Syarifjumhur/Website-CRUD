<?php

//menu utama
define ("language", 'Language');
define ("home", 'Home');
define ("services", 'Services');
define ("gallery", 'Gallery');
define ("aboutus", 'About Us');
define ("contactus", 'Contact US');

//tombol
define ("moredetail", "Our Services");
define ("buttoncontinue", "See Our Gallery");
define ("buttonsendemail", "Send Us a Message");

//judul
define ("labelservices", "Services");
define ("labelgallery", "Gallery");
define ("labelgallerydescription", "Our Service");
define ("labelaboutus", "About Us");
define ("labelcontactus", "Contact Us");

//form email
define ("placename", "Your Name...");
define ("placesubject", "Subject...");
define ("placeemail", "Your Email...");
define ("placemessage", "Your Message...");
define ("buttonsendmail", "Send Message");

//footer
define ("labellocation", "Location");
define ("labelheadoffice", "Head Office");
define ("labelphone", "Phone");
define ("labelemail", "Email");
define ("labelinfo", "More Info");
define ("labelsosmed", "Social Media");

?>